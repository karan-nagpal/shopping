<?php
include('header.php');
?>
<h3 class="text-center">Your orders</h3>
<?php
$usr = $_SESSION['userid'];
$cmd = "select * from orders where userid = '".$usr."'";
$data = mysqli_query($conn, $cmd);
$numrow = mysqli_num_rows($data);
if($numrow > 0){
    while($row = mysqli_fetch_array($data)){
?>
        <div class="col-md-9 col-md-offset-3" >
            <img src="../productimages/<?php echo $row['image']; ?>" alt="image" style="width:100px">
            <?php echo $row['address']; ?>
        </div>

<?php
    }
}










?>