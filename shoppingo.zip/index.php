<?php 
include('dbconnect.php');
include('header.php');
 ?>

      <?php include('slider.php'); ?>

      

      <div class="col-md-12 text-center">
        <?php
        // if(isset($_SESSION['uname'])){
          // include('nav.php');
        // } 
        ?>
        <div class="col-md-8 col-md-offset-2">
        <?php 
      $cmd = "select * from categories";
      $data = mysqli_query($conn, $cmd);
      $numrow = mysqli_num_rows($data);
      if($numrow <=0){
        echo "No data available";
      }else{
        while($row = mysqli_fetch_array($data)){?>

         
      
          <div class="col-md-3 col-md-offset-1">
            <div class="col-md-10 cardsview">
              <a href= "viewprobcat.php?cid=<?php echo $row['catid']; ?>"><img src="categoryimages/<?php echo $row['image'] ?>" class="img-responsive" alt="catimage" >
              <p><?php echo $row['name'] ?></p></a>
            </div>
          </div> 
          <?php
        }
      }?>  
          
      <div class="col-md-12 discounts">
    </div>
      </div>
    </div>
     <?php include('footer.php');?>