<div class="col-md-12 footer bg-theme">
        <div class="col-md-3 col-md-offset-1 "></div>
        <div class="col-md-3 col-md-offset-1"></div>
        <div class="col-md-3 col-md-offset-1 text-center">
          <p style="padding:5px; margin:5px">follow us</p>
          <ul style="list-style: none; padding:5px; margin:5px">
            <li>
              <i class="fa fa-facebook"></i>
            </li>
            <li>
              <i class="fa fa-twitter"></i>
            </li>
            <li>
              <i class="fa fa-instagram"></i>
            </li>
            <li>
              <i class="fa fa-pinterest"></i>
            </li>
          </ul>
        </div>
      </div>
</body>
</html>