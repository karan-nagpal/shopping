<?php

if(!isset($_SESSION['aid'])){
    header('location:index.php');
}
?>
<div class="col-md-2  text-center mt-5">
    <style>

        </style>
   <div class="col-md-10 border-bottom" style="padding:0 " >
        <a href="dashboard.php" class="btn  my-2 w-100 my-sm-0"  >My Dashboard</a>
    </div> 
    <div class="col-md-10 border-bottom" style="padding:0" >
        <a href="vieworders.php" class="btn my-2 w-100 my-sm-0" >View orders</a>
    </div>
    <div class="col-md-10 border-bottom" style="padding:0 " >
        <a href="addpro.php" class="btn  my-2 w-100 my-sm-0"  >Add products</a>
    </div> 
    <div class="col-md-10 border-bottom" style="padding:0" >
        <a href="addcat.php" class="btn   my-2 w-100 my-sm-0"  >Add new Category</a>
    </div> 
    <div class="col-md-10 border-bottom" style="padding:0" >
        <a href="viewpro.php" class="btn my-2 w-100 my-sm-0" >View products</a>
    </div> 
    <div class="col-md-10 border-bottom" style="padding:0" >
        <a href="addiscounts.php" class="btn  my-2 w-100 my-sm-0" >Add discount coupons</a>
    </div> 
    <div class="col-md-10 border-bottom" style="padding:0" >
        <a href="changepwd.php" class="btn  my-2 w-100 my-sm-0" >Change Password</a>
    </div> 
    <div class="col-md-10 border-bottom" style="padding:0" >
        <a href="logout.php" class="btn  my-2 w-100 my-sm-0">Logout</a>
    </div> 



</div>