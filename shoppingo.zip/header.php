<?php
session_start();
include('dbconnect.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/font-awesome.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body >
<nav class="navbar navbar-expand-lg navbar-light bg-theme">
  <a href="index.php"><img src="images/logo.png" id="logo" alt="logo"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse " id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contactUs.php">Contact Us</a>
      </li>
      <li class="nav-item dropdown">
        
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Choose from categories
        </a>
        <div class="dropdown-menu bg-theme" aria-labelledby="navbarDropdown">
        <?php
      $cmd = "select * from categories";
      $data = mysqli_query($conn, $cmd);
      $numrow = mysqli_num_rows($data);
      if($numrow <=0){
        echo "No data available";
      }else{
        while($row = mysqli_fetch_array($data)){?>
          <a class="dropdown-item" href="viewprobcat.php?cid=<?php echo $row['catid']; ?>"><?php echo $row['name']; ?></a>
          <div class="dropdown-divider"></div>
      <?php
        }
      }
      ?>  
      </div>
      </li>
      </ul>

      <form class="form-inline my-2 my-lg-0 searchi" >
        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
        <button class=" btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      </form>
    </div>
    
  </div>
  <div class="col-md-3 " >
    <div class="col-md-2 m-0 text-left">
    <i class="fa fa-heart-o pt-5" style="font-size:28px; color:white"></i>
    </div>
    <div class="col-md-2">
    <a href="cart.php">
            <?php
                if(isset($_SESSION['userid'])){
                 $userid = $_SESSION['userid'];
                 $cmd = "select * from cart where custid = '".$userid."'";
                 $data = mysqli_query($conn, $cmd);
                 $rows = mysqli_num_rows($data);
                if($rows>0){ ?> <span class="text-right bg-light ml-3" style="font-size:15px; color:green; width:18px;height:18px; border:3px solid white; border-radius:50%" > <?php echo $rows;} 
                }
            ?>
                </span>
              <?php
              if (isset($_SESSION['products'])){
                ?>
                <span  class="text-center bg-light" style="position:absolute; top:0 right:0;font-size:15px; color:green; width:18px;height:18px; border:3px solid white; border-radius:50%" >
              <?php 
              
              echo count($_SESSION['products']); 
              ?>
              </span>
              <?php
              }
              ?>
                <i class="fa fa-shopping-cart mt-5" id="cartlink" style="font-size:30px; color:white"  ></i> </a>
            </div>
            <div class="col-md-6 m-0 p-0 text-right">
              <?php  
          if(isset($_SESSION['uname'])){
            ?>
            
            
            <ul style="list-style:none">
              <li class="nav-item dropdown">
                
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fa fa-user-o"></i> 
                <?php
                      echo $_SESSION['uname']; ?>
                  </a>
                  <div class="dropdown-menu bg-theme p-4" aria-labelledby="navbarDropdown">
                    <a href="myorders.php">My orders</a></p>
                    <a href="wishlist.php">My Wishlist</a></p>
                    <a href="cart.php">My Cart</a></p>   
                    <a href="logout.php">Logout</a></p>
          </li>
         </ul>
            <?php     
          }else{
            echo "welcome Guest";
            ?>
             <p><a href="usereg.php">Register</a>
            <a href="userlogin.php">Login</a></p>
            <?php
          }
          
          ?>
          </div>
          
        </div>
</nav>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>