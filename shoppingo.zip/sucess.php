<?php 
include('dbconnect.php');
include('header.php');
 ?>
<div class="col-md-12 text-center"style="min-height:400px">
        Your Order has been placed Succesfully.

</div>
     <?php include('footer.php');?>