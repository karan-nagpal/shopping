<?php
include('header.php');

include('dbconnect.php');
include('leftnav.php');
?>
<div class="col-md-10"style="min-height:700px;"></div>
<?php

 

include('footer.php');
?>